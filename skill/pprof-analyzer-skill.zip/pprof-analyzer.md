# pprof-analyzer

Analyze Go pprof profiles and generate performance optimization patches without requiring an agent loop.

## Usage

```
/pprof-analyze <profile_path> <repo_path> <reference_level>
```

### Arguments

- `profile_path`: Path to the pprof profile file (`.pb.gz`, `.prof`, or `.pprof`)
- `repo_path`: Path to the Go repository to analyze (must be a git repo)
- `reference_level`: Analysis depth: `low`, `med`, or `high`
  - **low**: Fix only the single highest-impact hotspot with low-effort changes
  - **med**: Top hotspots with low/medium-effort fixes
  - **high**: All significant hotspots up to architectural changes

### Example

```bash
/pprof-analyze ./cpu.prof ./ med
```

## What It Does

1. **Converts** pprof profile to detailed markdown with call trees and hotspots
2. **Extracts** files mentioned in profile hotspots + their imports (smart selection)
3. **Passes all context** to Claude upfront (no back-and-forth tool calls)
4. **Generates** a unified diff patch with analysis summary
5. **Validates** patch with `git apply --check`
6. **Writes artifacts** to `.ai_output/` directory

## Output Files

All results go to `.ai_output/`:

- **patch.diff** — Unified diff patch ready to apply
- **summary.md** — Analysis table and explanation
- **analyzer_result.md** — Detailed pprof markdown
- **prompt.txt** — Full prompt sent to Claude (for debugging)

## Quick Start

```bash
# 1. Generate a CPU profile for your Go service
# (e.g., via http://localhost:6060/debug/pprof/profile)

# 2. Use the skill
/pprof-analyze cpu.prof ./ med

# 3. Review the results
cat .ai_output/summary.md
cat .ai_output/patch.diff

# 4. Apply if satisfied
git apply .ai_output/patch.diff

# 5. Review and commit
git diff
git add -A
git commit -m "perf: optimize hotspots per pprof analysis"
```

## Prerequisites

- Python 3.11+
- `pprof-to-md` CLI tool (installed via npm)
- `git` CLI
- Go toolchain (for some analysis)

## Installation

See [INSTALL.md](./INSTALL.md) for detailed setup instructions.

## How It Works

### Unlike the GitHub Action

The full action uses a **multi-turn agent loop**: it calls an LLM, the LLM uses a `read_file` tool to request specific source files, the action provides them, the LLM refines its analysis, etc.

This skill uses a **single-turn approach**: it collects all relevant source files upfront and passes them all to Claude in one go. This is:
- ✅ Simpler (no tool loop required)
- ✅ Faster (one API call, not 10+)
- ✅ Deterministic (no retry logic needed)

### The Trade-off

- **Pro**: Simpler, faster, no agent loop complexity
- **Con**: We include more source code upfront (but we smart-select, so it's manageable)

For most Go services, the hotspots are in a few key files. We include those files + their direct imports, capping at ~75KB of code. This is typically enough context for Claude to make good optimization suggestions.

## Configuration

No configuration needed! The skill uses Claude Code's built-in Claude model directly.

```bash
/pprof-analyze cpu.prof ./ med
```

That's it. No API keys, no endpoints to set up.

## Troubleshooting

**Q: "Profile file not found"**  
A: Check the profile path is correct: `pprof-analyze /path/to/cpu.prof ./ med`

**Q: "Repository is not a git repo"**  
A: The skill needs a git repo to find source files. Initialize one: `cd /path/to/repo && git init`

**Q: "Patch doesn't apply cleanly"**  
A: The patch might be for a different version of the code. Review `.ai_output/patch.diff` and apply manually if needed.

**Q: "Claude returned invalid patch"**  
A: Check `.ai_output/prompt.txt` to see what Claude received. You can also try a different reference level or add more context files.

## License

Same as pprof-analyzer action.
