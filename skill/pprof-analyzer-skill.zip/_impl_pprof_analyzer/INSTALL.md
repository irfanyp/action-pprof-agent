# Installation Guide

## Prerequisites

Before installing the pprof-analyzer skill, ensure you have:

- **Python 3.11+** — Required for the analyzer script
- **Node.js 18+** — Required for pprof-to-md (install npm packages)
- **Go toolchain** — For analyzing Go repositories
- **git** — For patch application
- **Claude Code** — With CLI tools enabled

## Quick Installation (Recommended)

```bash
unzip pprof-analyzer-skill.zip
cd pprof-analyzer-skill
./SETUP.sh install
```

✅ **Done!** Everything is installed automatically:
- Copies skill files to `~/.claude/skills/`
- Installs Python dependencies (GitPython)
- Installs Node.js dependencies (pprof-to-md)

---

## Manual Installation (Optional)

If you prefer to install step-by-step:

### 1. Extract the Package

```bash
unzip pprof-analyzer-skill.zip
cd pprof-analyzer-skill
```

### 2. Copy Skill Files

```bash
mkdir -p ~/.claude/skills
cp pprof-analyzer.md ~/.claude/skills/
cp -r _impl_pprof_analyzer ~/.claude/skills/
```

### 3. Install Python Dependencies

```bash
pip install GitPython
```

### 4. Install Node Dependencies (pprof-to-md)

```bash
npm install -g pprof-to-md
```

Or, if using a local installation:

```bash
cd ~/.claude/skills/_impl_pprof_analyzer
npm install
# Then update PATH or create a wrapper
```

### 5. Verify Installation

Test that the skill is available:

```bash
# In Claude Code:
/pprof-analyze --help
```

Expected output:
```
usage: analyzer.py [-h] [--output OUTPUT] profile repo {low,med,high}

Analyze Go pprof profiles and generate optimization patches
...
```

### 6. (Optional) Configure IDE Integration

**VS Code:**
Add to `.vscode/settings.json`:
```json
{
  "claude.enabled": true,
  "claude.skills": {
    "pprof-analyzer": {
      "path": "~/.claude/skills/_impl_pprof_analyzer"
    }
  }
}
```

**JetBrains IDEs (IntelliJ, GoLand, etc.):**
The skill should be automatically detected by Claude Code plugin.

## Configuration

The skill uses Claude Code's built-in Claude model. **No configuration needed!**

Just use it directly:
```bash
/pprof-analyze cpu.prof ./ med
```

## Troubleshooting

### Error: "pprof-to-md not found"

Install pprof-to-md globally:

```bash
npm install -g pprof-to-md
which pprof-to-md  # Verify it's in PATH
```

If using a local npm installation, ensure the path is in your PATH environment variable.

### Error: "Module 'openai' not found"

Reinstall Python dependencies:

```bash
pip install --upgrade -r ~/.claude/skills/_impl_pprof_analyzer/requirements.txt
```


### Error: "Repository is not a git repo"

Initialize git in your repository:

```bash
cd /path/to/repo
git init
git add .
git commit -m "Initial commit"
```

### Patch doesn't apply cleanly

This can happen if:
1. The code changed since the profile was generated
2. Claude's patch has syntax errors
3. Whitespace/indentation mismatch

**Solution:**
1. Check the prompt and patch in `.ai_output/`:
   ```bash
   cat .ai_output/prompt.txt
   cat .ai_output/patch.diff
   ```

2. Try with a different reference level or model:
   ```bash
   /pprof-analyze profile.prof ./ low  # More conservative
   /pprof-analyze --model gpt-4o profile.prof ./ med
   ```

3. Apply manually:
   ```bash
   patch < .ai_output/patch.diff
   # Resolve conflicts manually if needed
   ```

## Uninstallation

Remove the skill:

```bash
rm ~/.claude/skills/pprof-analyzer.md
rm -rf ~/.claude/skills/_impl_pprof_analyzer
```

Uninstall npm package (optional):

```bash
npm uninstall -g pprof-to-md
```

## Next Steps

- Read [README.md](README.md) for usage examples
- Check [workflow_example.md](workflow_example.md) for sample workflows
- Review example outputs in `examples/`

## Support

For issues or questions:
1. Check `.ai_output/prompt.txt` for what was sent to Claude
2. Review `.ai_output/llm_result.txt` for Claude's full response
3. Try running with a different reference level or model
4. Check system prerequisites are installed correctly
