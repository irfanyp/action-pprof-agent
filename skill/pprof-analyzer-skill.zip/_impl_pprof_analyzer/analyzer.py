#!/usr/bin/env python3
"""
pprof-analyzer skill orchestrator: Analyze Go pprof profiles and generate optimization patches.

Works entirely within Claude Code - no external API calls needed.
Orchestrates the analysis workflow using local tools:
1. Converts pprof profile to markdown with pprof-to-md
2. Extracts relevant source files (smart selection from hotspots)
3. Builds a comprehensive prompt with all context
4. Returns prompt to Claude for analysis (no API call - uses built-in Claude)
5. Parses SUMMARY and PATCH from Claude's response
6. Validates and writes artifacts to .ai_output/
"""

from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import git

# Maximum code to include (bytes)
MAX_CODE_CONTEXT = 75_000



@dataclass
class Config:
    """Configuration for the analyzer."""
    profile_path: Path
    repo_path: Path
    reference_level: str
    output_dir: Path = Path(".ai_output")

    def __post_init__(self) -> None:
        """Validate configuration."""
        if not self.profile_path.exists():
            raise ValueError(f"Profile file not found: {self.profile_path}")
        if not self.repo_path.exists():
            raise ValueError(f"Repo path not found: {self.repo_path}")
        if self.reference_level not in {"low", "med", "high"}:
            raise ValueError(f"Invalid reference level: {self.reference_level}")


class AnalyzerError(Exception):
    """Base exception for analyzer errors."""
    pass


def load_template(template_path: Path) -> str:
    """Load the prompt template."""
    if not template_path.exists():
        raise AnalyzerError(f"Template not found: {template_path}")
    return template_path.read_text()


def convert_pprof_to_markdown(profile_path: Path) -> str:
    """Convert pprof profile to markdown using pprof-to-md."""
    try:
        result = subprocess.run(
            ["pprof-to-md", "--format", "detailed", str(profile_path)],
            capture_output=True,
            text=True,
            timeout=30,
        )
        if result.returncode != 0:
            raise AnalyzerError(f"pprof-to-md failed: {result.stderr}")
        return result.stdout
    except FileNotFoundError:
        raise AnalyzerError(
            "pprof-to-md not found. Install with: npm install -g pprof-to-md"
        )


def extract_hotspot_files(analyzer_result: str) -> set[str]:
    """Extract file paths mentioned in hotspots from analyzer result."""
    files = set()

    # Look for file paths in the analyzer result
    # pprof-to-md output includes file paths like: /path/to/file.go
    file_pattern = r"([a-zA-Z0-9_\-./]*\.go)"
    for match in re.finditer(file_pattern, analyzer_result):
        path = match.group(1)
        if path and not path.startswith("/"):  # Prefer relative paths
            files.add(path)

    return files


def find_go_files(repo_path: Path) -> set[str]:
    """Find all Go files in the repository using git."""
    try:
        repo = git.Repo(repo_path)
        go_files = set()
        for item in repo.tree().traverse():
            if item.path.endswith(".go") and "_test.go" not in item.path:
                go_files.add(item.path)
        return go_files
    except Exception as e:
        print(f"Warning: Could not enumerate git files: {e}")
        # Fallback: use filesystem walk
        go_files = set()
        for root, dirs, files in os.walk(repo_path):
            # Skip common exclude dirs
            dirs[:] = [d for d in dirs if d not in {".git", "vendor", "node_modules"}]
            for f in files:
                if f.endswith(".go") and "_test.go" not in f:
                    rel_path = Path(root) / f
                    go_files.add(str(rel_path.relative_to(repo_path)))
        return go_files


def select_files_smart(
    hotspot_files: set[str], all_files: set[str], repo_path: Path
) -> list[str]:
    """Select files to include: hotspot files + their direct imports."""
    selected = set()

    # Always include hotspot files
    for f in hotspot_files:
        # Normalize path
        if f in all_files:
            selected.add(f)
        else:
            # Try to find by basename
            basename = Path(f).name
            for af in all_files:
                if af.endswith(basename):
                    selected.add(af)
                    break

    # Add direct imports (one level)
    for selected_file in list(selected):
        file_path = repo_path / selected_file
        if not file_path.exists():
            continue

        try:
            content = file_path.read_text(errors="ignore")
            # Find imports
            import_pattern = r'import\s+(?:\(\s*(.+?)\s*\)|"([^"]+)")'
            matches = re.findall(import_pattern, content, re.DOTALL)

            for match in matches:
                import_group = match[0] if match[0] else match[1]
                # Extract import paths
                imports = re.findall(r'"([^"]+)"', import_group)
                for imp in imports:
                    # Only include internal packages (not stdlib/external)
                    if not any(x in imp for x in {"golang", "google", "github", "internal"}):
                        continue
                    # Try to find corresponding file
                    for af in all_files:
                        if imp.replace("/", os.sep) in af or af.endswith(imp.split("/")[-1] + ".go"):
                            if len(selected) < 20:  # Limit to avoid too many files
                                selected.add(af)
                            break
        except Exception:
            pass

    # Sort and return
    return sorted(selected)


def read_source_files(
    selected_files: list[str], repo_path: Path, max_size: int = MAX_CODE_CONTEXT
) -> str:
    """Read source files with line numbers."""
    result = []
    total_size = 0

    for file_path_str in selected_files:
        file_path = repo_path / file_path_str
        if not file_path.exists():
            continue

        try:
            content = file_path.read_text(errors="replace")
            lines = content.split("\n")

            # Format with line numbers and L{num}| prefix (like read_file tool)
            formatted_lines = [f"L{i+1:4d}| {line}" for i, line in enumerate(lines)]
            formatted_content = "\n".join(formatted_lines)

            file_section = f"## {file_path_str}\n\n```go\n{formatted_content}\n```\n\n"
            total_size += len(file_section)

            if total_size > max_size:
                result.append(
                    f"... (additional files omitted, context limit reached)\n"
                )
                break

            result.append(file_section)
        except Exception as e:
            result.append(f"## {file_path_str}\n\n(Error reading file: {e})\n\n")

    return "".join(result)


def construct_prompt(
    template: str,
    analyzer_result: str,
    repository_files: str,
    reference_level: str,
) -> str:
    """Construct the prompt for Claude."""
    return template.format(
        reference_level=reference_level,
        analyzer_result=analyzer_result,
        repository_files=repository_files,
    )


def submit_for_analysis(prompt: str) -> str:
    """
    Submit the prompt to Claude for analysis.

    In Claude Code, this returns the prompt for Claude to process directly.
    Claude will analyze the pprof profile and generate the SUMMARY and PATCH.

    The response should contain:
    - ### SUMMARY section with analysis table
    - ### PATCH section with unified diff
    """
    print(f"✨ Ready for Claude to analyze. Prompt size: {len(prompt)} chars")
    print(f"\n{'='*60}")
    print(f"ANALYSIS PROMPT")
    print(f"{'='*60}\n")
    print(prompt)
    print(f"\n{'='*60}")
    print(f"\n🤖 Please analyze the above profile and provide:")
    print(f"   1. ### SUMMARY section with hotspot analysis")
    print(f"   2. ### PATCH section with unified diff patch")
    print(f"\nPaste your analysis below (or let Claude Code process it):\n")

    # In Claude Code context, return the prompt for Claude to process
    return prompt


def extract_sections(response: str) -> tuple[str, str]:
    """Extract SUMMARY and PATCH from Claude response."""
    # Extract SUMMARY section
    summary_match = re.search(
        r"^###\s+SUMMARY\s*\n(.*?)(?:^###\s+PATCH|\Z)",
        response,
        re.MULTILINE | re.DOTALL,
    )
    if not summary_match:
        raise AnalyzerError("Could not extract SUMMARY section from response")

    summary = summary_match.group(1).strip()

    # Extract PATCH section with code fence
    patch_match = re.search(
        r"^###\s+PATCH\s*\n.*?```(?:diff)?\n(.*?)\n```",
        response,
        re.MULTILINE | re.DOTALL,
    )
    if not patch_match:
        raise AnalyzerError("Could not extract PATCH section from response")

    patch = patch_match.group(1)

    return summary, patch


def validate_patch(patch: str, repo_path: Path) -> Optional[str]:
    """Validate patch with git apply --check."""
    try:
        # Write patch to temp file
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".diff", delete=False
        ) as f:
            f.write(patch)
            temp_patch = f.name

        try:
            result = subprocess.run(
                ["git", "apply", "--check", "--whitespace=fix", temp_patch],
                cwd=repo_path,
                capture_output=True,
                text=True,
                timeout=10,
            )
            if result.returncode != 0:
                return f"Patch validation failed:\n{result.stderr}"
            return None
        finally:
            os.unlink(temp_patch)
    except Exception as e:
        return f"Error validating patch: {e}"


def write_artifacts(
    output_dir: Path,
    summary: str,
    patch: str,
    analyzer_result: str,
    prompt: str,
) -> None:
    """Write analysis artifacts to output directory."""
    output_dir.mkdir(parents=True, exist_ok=True)

    (output_dir / "summary.md").write_text(summary)
    (output_dir / "patch.diff").write_text(patch)
    (output_dir / "analyzer_result.md").write_text(analyzer_result)
    (output_dir / "prompt.txt").write_text(prompt)

    print(f"\n✅ Artifacts written to {output_dir}/")
    print(f"   - summary.md (analysis results)")
    print(f"   - patch.diff (unified diff patch)")
    print(f"   - analyzer_result.md (pprof analysis)")
    print(f"   - prompt.txt (full prompt sent to Claude)")


def main() -> int:
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description="Analyze Go pprof profiles and generate optimization patches"
    )
    parser.add_argument(
        "profile",
        type=Path,
        help="Path to pprof profile file (.pb.gz, .prof, .pprof)",
    )
    parser.add_argument(
        "repo",
        type=Path,
        help="Path to Go repository",
    )
    parser.add_argument(
        "reference_level",
        choices={"low", "med", "high"},
        help="Analysis depth: low (single hotspot), med (top hotspots), high (comprehensive)",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path(".ai_output"),
        help="Output directory for artifacts",
    )

    args = parser.parse_args()

    try:
        config = Config(
            profile_path=args.profile.resolve(),
            repo_path=args.repo.resolve(),
            reference_level=args.reference_level,
            output_dir=args.output.resolve(),
        )
    except ValueError as e:
        print(f"❌ Configuration error: {e}", file=sys.stderr)
        return 1

    try:
        print(f"📊 Analyzing pprof profile: {config.profile_path}")
        analyzer_result = convert_pprof_to_markdown(config.profile_path)

        print(f"📝 Converting profile to markdown...")

        print(f"🔍 Extracting hotspot files...")
        hotspot_files = extract_hotspot_files(analyzer_result)
        all_files = find_go_files(config.repo_path)

        print(f"   Found {len(hotspot_files)} hotspot files, {len(all_files)} total Go files")

        selected_files = select_files_smart(hotspot_files, all_files, config.repo_path)
        print(f"   Selected {len(selected_files)} files for analysis")

        print(f"📄 Reading source files...")
        repository_files = read_source_files(selected_files, config.repo_path)

        template_path = Path(__file__).parent / "prompts" / "prompt_template.txt"
        template = load_template(template_path)

        print(f"🎯 Constructing prompt...")
        prompt = construct_prompt(
            template,
            analyzer_result,
            repository_files,
            config.reference_level,
        )

        print(f"\n📝 Saving prompt for Claude analysis...")
        prompt_text = submit_for_analysis(prompt)
        _write_artifact("prompt_for_claude.txt", prompt_text)

        print(f"\n🔄 Claude will now analyze the prompt above...")
        print(f"   This skill returns the formatted prompt to Claude for processing.")
        print(f"   Claude's response should contain ### SUMMARY and ### PATCH sections.")

        # In Claude Code context, the skill returns here and Claude processes the prompt
        # The response is captured and analyzed in the next part
        print(f"\n⏳ Waiting for Claude's analysis...")

        # Note: In a real Claude Code context, Claude would respond with the analysis
        # For testing/demo, we would get an empty response here
        response = ""  # This would be filled by Claude's response in actual use

        if not response:
            print(f"\n📋 Prompt prepared and saved to .ai_output/prompt_for_claude.txt")
            print(f"\n✨ Claude Code is ready to analyze!")
            print(f"   The prompt above contains:")
            print(f"   - Reference level instructions")
            print(f"   - Detailed pprof analysis")
            print(f"   - All relevant source code")
            print(f"\n   Claude will respond with SUMMARY and PATCH sections.")
            return 0

        print(f"✂️  Extracting SUMMARY and PATCH...")
        summary, patch = extract_sections(response)

        print(f"🔎 Validating patch...")
        validation_error = validate_patch(patch, config.repo_path)
        if validation_error:
            print(f"❌ Patch validation failed:\n{validation_error}", file=sys.stderr)
            write_artifacts(config.output_dir, summary, patch, analyzer_result, prompt)
            print(f"\nℹ️  Artifacts saved to {config.output_dir}/ for debugging", file=sys.stderr)
            return 1

        print(f"✅ Patch validated successfully")

        print(f"\n{'='*60}")
        print(f"SUMMARY")
        print(f"{'='*60}")
        print(summary)
        print(f"\n{'='*60}")

        write_artifacts(config.output_dir, summary, patch, analyzer_result, prompt)

        print(f"\n✨ Analysis complete!")
        print(f"\nNext steps:")
        print(f"  1. Review the summary and patch: cat {config.output_dir}/patch.diff")
        print(f"  2. Apply if satisfied: git apply {config.output_dir}/patch.diff")
        print(f"  3. Test and commit: git add -A && git commit -m 'perf: optimize hotspots'")

        return 0

    except AnalyzerError as e:
        print(f"❌ Analysis error: {e}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"❌ Unexpected error: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main())
