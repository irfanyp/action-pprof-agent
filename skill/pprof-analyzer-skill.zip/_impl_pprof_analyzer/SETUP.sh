#!/bin/bash

set -e

SKILLS_DIR="${HOME}/.claude/skills"
SKILL_NAME="pprof-analyzer"
IMPL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

case "${1:-install}" in
    install)
        echo "📦 Installing pprof-analyzer skill..."

        # Create skills directory
        mkdir -p "$SKILLS_DIR"

        # Copy skill definition
        cp "$IMPL_DIR/../pprof-analyzer.md" "$SKILLS_DIR/"
        echo "✅ Copied pprof-analyzer.md"

        # Copy implementation
        cp -r "$IMPL_DIR" "$SKILLS_DIR/_impl_pprof_analyzer"
        echo "✅ Copied _impl_pprof_analyzer/"

        # Install Python dependencies
        echo "📦 Installing Python dependencies..."
        if command -v pip3 &> /dev/null; then
            pip3 install -r "$IMPL_DIR/requirements.txt"
        elif command -v pip &> /dev/null; then
            pip install -r "$IMPL_DIR/requirements.txt"
        else
            echo "❌ pip not found. Install Python 3.11+"
            exit 1
        fi
        echo "✅ Python dependencies installed"

        # Install pprof-to-md
        echo "📦 Installing pprof-to-md..."
        if command -v npm &> /dev/null; then
            npm install -g pprof-to-md
            echo "✅ pprof-to-md installed"
        else
            echo "⚠️  npm not found. Install Node.js 18+"
            echo "   Then run: npm install -g pprof-to-md"
            exit 1
        fi

        # Check for git
        if ! command -v git &> /dev/null; then
            echo "❌ git not found. Install git first."
            exit 1
        fi
        echo "✅ git found"

        echo ""
        echo "✨ Installation complete!"
        echo ""
        echo "Next steps:"
        echo "  1. Verify: /pprof-analyze --help (in Claude Code)"
        echo "  2. Set environment variables:"
        echo "     export AI_ENDPOINT='https://api.openai.com/v1'"
        echo "     export AI_KEY='sk-...'"
        echo "  3. Try an example: /pprof-analyze examples/sample.pb.gz ./ med"
        echo ""
        echo "See INSTALL.md for detailed setup instructions."
        ;;

    uninstall)
        echo "🗑️  Uninstalling pprof-analyzer skill..."

        rm -f "$SKILLS_DIR/pprof-analyzer.md"
        rm -rf "$SKILLS_DIR/_impl_pprof_analyzer"

        echo "✅ Uninstalled"
        echo ""
        echo "Optional: npm uninstall -g pprof-to-md"
        ;;

    verify)
        echo "🔍 Verifying pprof-analyzer skill installation..."
        echo ""

        # Check Python
        if command -v python3 &> /dev/null; then
            echo "✅ Python 3: $(python3 --version)"
        else
            echo "❌ Python 3 not found"
        fi

        # Check pip
        if command -v pip3 &> /dev/null; then
            echo "✅ pip3 found"
        else
            echo "⚠️  pip3 not found (but may not be needed)"
        fi

        # Check Node/npm
        if command -v npm &> /dev/null; then
            echo "✅ npm: $(npm --version)"
        else
            echo "⚠️  npm not found"
        fi

        # Check pprof-to-md
        if command -v pprof-to-md &> /dev/null; then
            echo "✅ pprof-to-md installed"
        else
            echo "❌ pprof-to-md not found"
            echo "   Install with: npm install -g pprof-to-md"
        fi

        # Check git
        if command -v git &> /dev/null; then
            echo "✅ git: $(git --version)"
        else
            echo "❌ git not found"
        fi

        # Check skill file
        if [ -f "$SKILLS_DIR/pprof-analyzer.md" ]; then
            echo "✅ Skill definition found at $SKILLS_DIR/pprof-analyzer.md"
        else
            echo "❌ Skill definition not found"
        fi

        # Check implementation directory
        if [ -d "$SKILLS_DIR/_impl_pprof_analyzer" ]; then
            echo "✅ Implementation found at $SKILLS_DIR/_impl_pprof_analyzer"
        else
            echo "❌ Implementation not found"
        fi

        # Try importing Python modules
        echo ""
        echo "Checking Python dependencies..."
        if python3 -c "import openai; import git; print('✅ All Python modules available')" 2>/dev/null; then
            :
        else
            echo "❌ Some Python modules missing"
            echo "   Run: pip install -r $IMPL_DIR/requirements.txt"
        fi
        ;;

    help|--help|-h)
        cat <<EOF
pprof-analyzer skill setup utility

Usage: $0 [COMMAND]

Commands:
  install      Install or update the skill (default)
  uninstall    Remove the skill
  verify       Check if everything is installed correctly
  help         Show this help message

Environment Variables:
  HOME         User home directory (for ~/.claude/skills)

Examples:
  # Install the skill
  $0 install

  # Check installation
  $0 verify

  # Remove the skill
  $0 uninstall

For detailed setup instructions, see INSTALL.md
EOF
        ;;

    *)
        echo "Unknown command: $1"
        echo "Run '$0 help' for usage information."
        exit 1
        ;;
esac
