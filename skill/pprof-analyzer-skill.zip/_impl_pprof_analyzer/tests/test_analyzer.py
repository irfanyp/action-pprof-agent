#!/usr/bin/env python3
"""Tests for the pprof-analyzer skill."""

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

# Add parent directory to path for imports
import sys
sys.path.insert(0, str(Path(__file__).parent.parent))

from analyzer import (
    extract_sections,
    extract_hotspot_files,
    select_files_smart,
)


class TestExtractSections:
    """Test SUMMARY and PATCH extraction from Claude response."""

    def test_extract_valid_response(self):
        """Test extracting both sections from valid response."""
        response = """
Some preamble here.

### SUMMARY

| ID | File | Function | Self % | Reduction | Confidence | Priority |
|---|---|---|---|---|---|---|
| 1 | main.go | processRequest | 15% | 15% | High | 1 |

This is a fix for the main hotspot.

### PATCH

```diff
--- a/main.go
+++ b/main.go
@@ -10,6 +10,6 @@
 func processRequest() {
-	x := make([]int, 0)
+	x := make([]int, 0, 100)
 	// process
 }
```

Some closing remarks.
"""
        summary, patch = extract_sections(response)

        assert "processRequest" in summary
        assert "15%" in summary
        assert "--- a/main.go" in patch
        assert "make([]int, 0, 100)" in patch

    def test_extract_missing_summary(self):
        """Test error when SUMMARY section is missing."""
        response = "### PATCH\n```diff\n--- a/file\n```"
        with pytest.raises(Exception):
            extract_sections(response)

    def test_extract_missing_patch(self):
        """Test error when PATCH section is missing."""
        response = "### SUMMARY\nSome text"
        with pytest.raises(Exception):
            extract_sections(response)


class TestExtractHotspotFiles:
    """Test extracting file paths from analyzer result."""

    def test_extract_go_files(self):
        """Test extracting .go file paths."""
        analyzer_result = """
## Hotspots

- main.go:ProcessRequest (15.2%)
- utils/cache.go:GetFromCache (8.5%)
- models/user.go:LoadUser (6.2%)
"""
        files = extract_hotspot_files(analyzer_result)

        assert "main.go" in files
        assert "utils/cache.go" in files
        assert "models/user.go" in files

    def test_no_duplicate_files(self):
        """Test that duplicate files are not extracted."""
        analyzer_result = """
main.go (15%)
main.go (5% nested call)
"""
        files = extract_hotspot_files(analyzer_result)
        assert len([f for f in files if f == "main.go"]) == 1


class TestSelectFilesSmart:
    """Test smart file selection."""

    def test_select_hotspot_files(self):
        """Test that hotspot files are always included."""
        hotspot_files = {"main.go", "utils.go"}
        all_files = {"main.go", "utils.go", "tests.go", "other.go"}
        repo_path = Path(".")

        selected = select_files_smart(hotspot_files, all_files, repo_path)

        assert "main.go" in selected
        assert "utils.go" in selected

    def test_select_limits_total_files(self):
        """Test that selection doesn't get out of hand."""
        hotspot_files = {"main.go"}
        all_files = {f"file{i}.go" for i in range(100)}
        repo_path = Path(".")

        selected = select_files_smart(hotspot_files, all_files, repo_path)

        # Should limit to a reasonable number
        assert len(selected) <= 30


@pytest.mark.integration
class TestIntegration:
    """Integration tests (require actual setup)."""

    def test_end_to_end(self, tmp_path):
        """Test a complete analysis flow (requires pprof-to-md)."""
        # This would require:
        # 1. A test Go project
        # 2. A sample pprof profile
        # 3. Mock Claude responses
        # For now, just verify the structure
        pass
