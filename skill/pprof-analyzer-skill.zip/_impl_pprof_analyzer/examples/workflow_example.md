# pprof-analyzer Skill Workflow Example

This document walks through a complete pprof-analyzer workflow with a real example.

## Scenario

You have a Go API service running on `http://localhost:8080`. Over time, it's gotten slower. You want to identify the hotspots and optimize them.

## Step 1: Generate a CPU Profile

First, expose the pprof endpoint in your service (see [pprof_integration.md](../pprof_integration.md) if you haven't already):

```go
package main

import (
	_ "net/http/pprof"
	"net/http"
)

func main() {
	go http.ListenAndServe("localhost:6060", nil)
	// ... rest of your app
}
```

Then generate a 30-second CPU profile:

```bash
curl http://localhost:6060/debug/pprof/profile?seconds=30 > cpu.prof
```

This waits 30 seconds while your service runs, capturing CPU usage.

## Step 2: Run the pprof-analyzer Skill

Navigate to your service repository and run the skill:

```bash
export AI_ENDPOINT="https://api.anthropic.com"
export AI_KEY="sk-your-key"

/pprof-analyze cpu.prof ./ med
```

Example output:

```
📊 Analyzing pprof profile: /home/user/service/cpu.prof
📝 Converting profile to markdown...
🔍 Extracting hotspot files...
   Found 3 hotspot files, 47 total Go files
   Selected 5 files for analysis
📄 Reading source files...
🎯 Constructing prompt...
🤖 Calling Claude (claude-opus-5)...
✂️  Extracting SUMMARY and PATCH...
🔎 Validating patch...
✅ Patch validated successfully

============================================================
SUMMARY
============================================================

| ID | File Path | Function | Self % (measured) | Max Theoretical Reduction | Confidence | Priority (1-5) |
|---|---|---|---|---|---|---|
| 1 | handlers/requests.go | parseRequestBody | 24.2% | 24.2% | High (n=5680) | 1 |
| 2 | cache/cache.go | Get | 15.8% | 15.8% | High (n=5680) | 2 |
| 3 | models/user.go | LoadFromDB | 8.5% | 8.5% | High (n=5680) | 3 |

\* Amdahl's-law upper bound assuming the fix fully eliminates this hotspot's measured cost...

### Root Cause Analysis

**Hotspot 1: parseRequestBody (24.2% self)**

The JSON parsing was allocating a new byte buffer for every request. By pre-allocating a buffer pool, we can reuse buffers across requests, reducing GC pressure significantly.

**Hotspot 2: cache.Get (15.8% self)**

The cache was using a mutex-protected map, causing lock contention. We replace it with sync.Map for better concurrent reads.

**Hotspot 3: LoadFromDB (8.5% self)**

The query was missing an index on the user_id column. Added the index to the schema.

============================================================

✨ Analysis complete!

Next steps:
  1. Review the summary and patch: cat .ai_output/patch.diff
  2. Apply if satisfied: git apply .ai_output/patch.diff
  3. Test and commit: git add -A && git commit -m 'perf: optimize hotspots'
```

## Step 3: Review the Patch

Let's check what changes Claude proposes:

```bash
cat .ai_output/patch.diff
```

Example output:

```diff
--- a/handlers/requests.go
+++ b/handlers/requests.go
@@ -1,6 +1,7 @@
 package handlers

 import (
+	"bytes"
 	"encoding/json"
 	"net/http"
 )

@@ -10,11 +11,25 @@ import (
+var bufferPool = sync.Pool{
+	New: func() interface{} {
+		return new(bytes.Buffer)
+	},
+}
+
 func parseRequestBody(r *http.Request) (map[string]interface{}, error) {
-	decoder := json.NewDecoder(r.Body)
+	buf := bufferPool.Get().(*bytes.Buffer)
+	defer func() {
+		buf.Reset()
+		bufferPool.Put(buf)
+	}()
+	_, err := io.Copy(buf, r.Body)
+	if err != nil {
+		return nil, err
+	}
+	decoder := json.NewDecoder(buf)
 	var result map[string]interface{}
 	err := decoder.Decode(&result)
 	return result, err
 }

--- a/cache/cache.go
+++ b/cache/cache.go
@@ -2,18 +2,19 @@ package cache

-import "sync"
+import (
+	"sync"
+)

-type Cache struct {
-	mu    sync.Mutex
-	items map[string]interface{}
-}

-func (c *Cache) Get(key string) (interface{}, bool) {
-	c.mu.Lock()
-	defer c.mu.Unlock()
-	v, ok := c.items[key]
-	return v, ok
-}
+var items sync.Map

+func Get(key string) (interface{}, bool) {
+	return items.Load(key)
+}

... (more changes for models/user.go with database schema migration comment)
```

This looks good! The changes are:
1. ✅ Low/medium effort (no architecture changes)
2. ✅ Focused on the hotspots
3. ✅ Well-commented
4. ✅ Should apply cleanly

## Step 4: Apply the Patch

```bash
git apply .ai_output/patch.diff
```

If it applies cleanly (no output = success):

```bash
git status
```

Output:

```
On branch main
Changes not staged for commit:
  (use "git add <file>..." to update the what will be committed)
  (use "git restore <file>..." to discard changes in working directory)
	modified:   handlers/requests.go
	modified:   cache/cache.go
	modified:   models/user.go
```

## Step 5: Test Locally

Run your tests to make sure nothing broke:

```bash
go test ./...
```

Run your application and verify it still works:

```bash
go run .
```

Test it with a client:

```bash
curl -X GET http://localhost:8080/api/users
```

## Step 6: Benchmark the Improvement

Re-run the profiler and compare:

```bash
# Generate a new profile with the changes applied
curl http://localhost:6060/debug/pprof/profile?seconds=30 > cpu-after.prof

# Compare profiles (optional, using pprof CLI)
go tool pprof -http=:8081 cpu.prof
# then compare with cpu-after.prof in a new tab
```

Expected result: **CPU usage down ~40% (sum of fixed hotspots)** if all fixes are effective. (In practice, it might be less due to contention or other factors.)

## Step 7: Commit and Create PR

Commit your changes:

```bash
git add -A
git commit -m "perf: optimize hotspots per pprof analysis

Analyzed CPU profile with pprof-analyzer skill:
- Buffer pooling in parseRequestBody (-24.2% CPU)
- Switched cache to sync.Map (-15.8% CPU)
- Added database index on user_id (-8.5% CPU)

Total potential CPU reduction: ~48.5%
(Measured with pprof, n=5680 samples)

See .ai_output/summary.md for detailed analysis.
"
```

Push and create a PR:

```bash
git push origin main
```

(Or create a new branch first: `git checkout -b perf/optimize-hotspots`)

## Advanced: Different Reference Levels

### Conservative Analysis (low)

For a more conservative fix focusing only on the top hotspot:

```bash
/pprof-analyze cpu.prof ./ low
```

Expected: Fewer changes, lower risk, less impact.

### Deep Analysis (high)

For a comprehensive optimization including all significant hotspots and architecture changes:

```bash
/pprof-analyze cpu.prof ./ high
```

Expected: More changes, higher risk, higher potential impact.

## Troubleshooting

### Patch doesn't apply cleanly

This can happen if the code changed since the profile was generated.

```bash
# Check what the conflict is
cat .ai_output/patch.diff

# Try applying manually with patch command
patch < .ai_output/patch.diff

# Or resolve with your editor
git apply --reject .ai_output/patch.diff
# Fixes hunks in *.rej files that you can manually apply
```

### Claude generated incorrect code

1. Review the prompt: `cat .ai_output/prompt.txt`
2. Check if the profile is correct: `cat .ai_output/analyzer_result.md`
3. Try with a different model or reference level

### Profile shows no application code hotspots

This can happen if:
- The bottleneck is in Go runtime/stdlib (not fixable at app level)
- The profile is too short (increase to 60 seconds)
- The workload isn't representative

In this case, the skill will still output a patch with a comment explaining why.

## Next Steps

- Iterate: Re-profile after each optimization to find the next bottleneck
- Monitor: Add metrics to track CPU usage in production
- Share: Use `./SETUP.sh install` to give teammates access to the skill

---

**Tips:**
- Profile under realistic load (simulate your production traffic)
- Profile for long enough (30-60 seconds, more for rare hotspots)
- Re-profile after each optimization to measure the impact
- Use `reference_level=low` for conservative changes, `high` for aggressive optimization
